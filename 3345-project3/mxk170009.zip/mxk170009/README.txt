Muhammad Khizar
mxk170009
Submitting project 3 -> Lazy Binary Search Tree
Professor- Sruthi Chappidi

Project includes 2 files:
- project3.java -> main file
- LazyBinarySearchTree.java -> Class file, has 2 classes -> lazybst and tree node classes

Used eclipse IDE

Commands used: 

Insert:140
Delete:2
FindMin
PrintTree
FindMax
Size
Height
Insert:85
Insert:63
Insert:74
Insert:100
Contains:50
FindMin
FindMax
Size
Height
Contains:63
Insert:86
Insert:88
Insert:87
FindMin
FindMax
PrintTree
Delete:88
Delete:74
Delete:85
PrintTree
FindMin
FindMax
Insert:74
PrintTree
Insert:85
PrintTree

Output: 
Error in Insert: IllegalArgumentException raised
false
-1

-1
0
-1
true
true
true
Error in Insert: IllegalArgumentException raised
false
63
85
3
2
true
true
true
true
63
88
85 63 74 86 88 87 
true
true
true
*85 63 *74 86 *88 87 
63
87
true
*85 63 74 86 *88 87 
true
85 63 74 86 *88 87 